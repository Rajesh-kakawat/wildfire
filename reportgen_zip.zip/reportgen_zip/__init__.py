"""
reportgen - Enterprise-grade Python library for generating
Excel and PDF reports from a single declarative configuration.

Inspired by Pentaho Reporting concepts (single definition → multiple formats,
complex header merging, styling), but implemented in modern Python.
"""

__version__ = "0.1.0"
from .config.loader import load_report_config
from .generators.excel import ExcelReportGenerator
from .generators.pdf import PDFReportGenerator

# Note: For PDF generation you need to install WeasyPrint:
#   pip install weasyprint
#
# WeasyPrint is fully free and open source (BSD license).
# It gives excellent support for merged header cells using HTML colspan + CSS.