import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from reportgen.config.loader import load_report_config
from reportgen.generators.excel import ExcelReportGenerator
from reportgen.generators.pdf import PDFReportGenerator

# Sample Data for Complex Report
data = [
    {
        "zone": "North",
        "product_category": "Home Loans",
        "q1_revenue": 2450.75,
        "q2_revenue": 2680.40,
        "total_cost": 1890.30,
        "gross_profit": 790.45,
        "margin_percent": 0.295,
        "npa_ratio": 0.018,
        "compliance_score": 95,
        "audit_status": "Passed"
    },
    {
        "zone": "South",
        "product_category": "Credit Cards",
        "q1_revenue": 1870.20,
        "q2_revenue": 2010.60,
        "total_cost": 1340.50,
        "gross_profit": 670.10,
        "margin_percent": 0.333,
        "npa_ratio": 0.024,
        "compliance_score": 88,
        "audit_status": "Passed"
    },
    {
        "zone": "East",
        "product_category": "Personal Loans",
        "q1_revenue": 1320.45,
        "q2_revenue": 1450.80,
        "total_cost": 980.75,
        "gross_profit": 470.05,
        "margin_percent": 0.324,
        "npa_ratio": 0.031,
        "compliance_score": 92,
        "audit_status": "Pending"
    },
    {
        "zone": "West",
        "product_category": "Vehicle Loans",
        "q1_revenue": 980.60,
        "q2_revenue": 1050.30,
        "total_cost": 720.40,
        "gross_profit": 330.50,
        "margin_percent": 0.314,
        "npa_ratio": 0.042,
        "compliance_score": 85,
        "audit_status": "Failed"
    }
]

# Load config and generate report
config = load_report_config("templates/complex_sales_report.yaml")

ExcelReportGenerator().generate(
    config=config,
    data=data,
    output_path="output/complex_sales_report.xlsx"
)

# 4. Generate PDF (requires: pip install weasyprint)
PDFReportGenerator().generate(config, data, "output/complex_sales_report.pdf")

print("✅ Complex Sales Report generated successfully!")