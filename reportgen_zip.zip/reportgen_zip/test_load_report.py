import sys
import os
import random
from datetime import datetime, timedelta
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from reportgen.config.loader import load_report_config
from reportgen.generators.excel import ExcelReportGenerator
from reportgen.generators.pdf import PDFReportGenerator

def generate_large_data(num_rows=5000):
    data = []
    start_date = datetime(2026, 1, 1)
    regions = ["North", "South", "East", "West", "Central"]
    
    for i in range(num_rows):
        row = {
            "id": f"CUST_{100000 + i}",
            "date": (start_date + timedelta(days=random.randint(0, 180))).strftime("%Y-%m-%d"),
            "region": random.choice(regions),
            "metric_50": round(random.uniform(100.0, 9999.99), 2)
        }
        data.append(row)
    return data

# Generate data and report
data = generate_large_data(5000)   # Change number as needed for testing

config = load_report_config("templates/load_test_report.yaml")

ExcelReportGenerator().generate(
    config=config,
    data=data,
    output_path="output/load_test_report.xlsx"
)

# 4. Generate PDF (requires: pip install weasyprint)
#PDFReportGenerator().generate(config, data, "output/load_test_report.pdf")


print(f"✅ Load Test Report generated with {len(data)} rows successfully!")