from typing import List, Optional, Dict, Any, Literal
from pydantic import BaseModel, Field, field_validator, model_validator
from enum import Enum

class DataType(str, Enum):
    STRING = "string"
    INTEGER = "integer"
    FLOAT = "float"
    CURRENCY = "currency"
    DATE = "date"
    PERCENTAGE = "percentage"
    BOOLEAN = "boolean"

class Alignment(str, Enum):
    LEFT = "left"
    CENTER = "center"
    RIGHT = "right"

class StyleDef(BaseModel):
    font_name: str = "Arial"
    font_size: int = 10
    bold: bool = False
    italic: bool = False
    text_color: str = "#000000"
    bg_color: Optional[str] = None
    border: bool = True
    border_color: str = "#B4B4B4"
    border_width: int = 1
    alignment: Alignment = Alignment.LEFT
    vertical_alignment: Literal["top", "middle", "bottom"] = "middle"
    wrap_text: bool = True

class HeaderCell(BaseModel):
    text: str
    colspan: int = 1
    style: str = "sub_header"

class HeaderRow(BaseModel):
    cells: List[HeaderCell]

class ColumnDef(BaseModel):
    key: str
    display_name: str
    width_excel: int = 15
    width_pdf: int = 90
    data_type: DataType = DataType.STRING
    format: Optional[str] = None
    alignment: Alignment = Alignment.LEFT
    style: str = "data_cell"

class TableConfig(BaseModel):
    header_rows: List[HeaderRow] = Field(default_factory=list)
    columns: List[ColumnDef]

    @model_validator(mode='after')
    def validate_header_spans(self):
        if not self.header_rows:
            return self
        total_cols = len(self.columns)
        for row_idx, hrow in enumerate(self.header_rows):
            current_span = sum(cell.colspan for cell in hrow.cells)
            if current_span != total_cols:
                raise ValueError(f"Header row {row_idx} colspan mismatch")
        return self

class ReportConfig(BaseModel):
    title: str
    subtitle: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)
    table: TableConfig
    styles: Dict[str, StyleDef] = Field(default_factory=dict)
    page: Dict[str, Any] = Field(default_factory=dict)