import yaml
import json
from pathlib import Path
from typing import Union
from .models import ReportConfig

def load_report_config(path: Union[str, Path]) -> ReportConfig:
    path = Path(path)
    if path.suffix.lower() in (".yaml", ".yml"):
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
    elif path.suffix.lower() == ".json":
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    else:
        raise ValueError("Only .yaml or .json supported")
    return ReportConfig(**data.get("report", data))