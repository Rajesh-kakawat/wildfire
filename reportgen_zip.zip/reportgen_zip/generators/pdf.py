"""
PDF Report Generator using WeasyPrint (fully free & open source).

Generates high-quality PDF with multi-row headers + merged cells (colspan)
by building clean HTML + CSS (very close to Pentaho table rendering).
"""

from typing import List, Dict, Any
import html
from weasyprint import HTML, CSS
from ..config.models import ReportConfig
from .base import BaseReportGenerator


class PDFReportGenerator(BaseReportGenerator):
    """Generates professional PDF reports using WeasyPrint + HTML table."""

    def generate(
        self,
        config: ReportConfig,
        data: List[Dict[str, Any]],
        output_path: str
    ) -> str:
        html_content = self._build_html(config, data)
        css_content = self._build_css(config)

        html_doc = HTML(string=html_content, base_url=".")
        html_doc.write_pdf(
            output_path,
            stylesheets=[CSS(string=css_content)]
        )
        return output_path

    def _build_html(self, config: ReportConfig, data: List[Dict[str, Any]]) -> str:
        """Build semantic HTML table with multi-row header + colspan (Pentaho style)."""
        cols = config.table.columns

        title_html = f"<h1 class='report-title'>{html.escape(config.title)}</h1>"
        if config.subtitle:
            title_html += f"<h2 class='report-subtitle'>{html.escape(config.subtitle)}</h2>"

        thead_rows = ""
        for hrow in config.table.header_rows:
            tr = "<tr>"
            for cell in hrow.cells:
                colspan_attr = f' colspan="{cell.colspan}"' if cell.colspan > 1 else ""
                tr += f'<th class="{cell.style}"{colspan_attr}>{html.escape(cell.text)}</th>'
            tr += "</tr>"
            thead_rows += tr

        tbody_rows = ""
        for record in data:
            tr = "<tr>"
            for col in cols:
                value = record.get(col.key, "")
                if col.data_type.value == "currency" and isinstance(value, (int, float)):
                    display_value = f"₹ {value:,.2f}"
                elif col.data_type.value == "percentage" and isinstance(value, (int, float)):
                    display_value = f"{value*100:.2f}%"
                else:
                    display_value = str(value)
                tr += f'<td class="{col.style}">{html.escape(display_value)}</td>'
            tr += "</tr>"
            tbody_rows += tr

        colgroup = "".join([f'<col style="width: {col.width_pdf}px;">' for col in cols])

        html_doc = f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>{html.escape(config.title)}</title>
</head>
<body>
    <div class="report-container">
        {title_html}
        <table class="report-table">
            <colgroup>{colgroup}</colgroup>
            <thead>
                {thead_rows}
            </thead>
            <tbody>
                {tbody_rows}
            </tbody>
        </table>
    </div>
</body>
</html>
"""
        return html_doc

    def _build_css(self, config: ReportConfig) -> str:
        """Generate CSS from the styles defined in config."""
        return """
            @page { size: A4 landscape; margin: 0.6in; }
            body { font-family: Arial, sans-serif; font-size: 9pt; color: #333; }
            .report-container { width: 100%; }
            .report-title { font-size: 16pt; font-weight: bold; text-align: center; margin-bottom: 4px; }
            .report-subtitle { font-size: 11pt; text-align: center; margin-bottom: 12px; color: #555; }
            .report-table { width: 100%; border-collapse: collapse; table-layout: fixed; }
            .report-table th, .report-table td { padding: 6px 8px; border: 1px solid #ccc; }
            .report-table th { background-color: #d6dce5; font-weight: bold; text-align: center; }
            .group_header { background-color: #1F4E79 !important; color: white !important; font-weight: bold; text-align: center; }
            .sub_header { background-color: #D6DCE5 !important; font-weight: bold; text-align: center; }
            .data_cell { text-align: right; }
        """