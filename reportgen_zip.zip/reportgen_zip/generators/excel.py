"""
Excel Report Generator using openpyxl.
Supports multi-row headers with merged cells (colspan) - Pentaho style.
"""

from typing import List, Dict, Any
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment
from openpyxl.utils import get_column_letter
from ..config.models import ReportConfig
from .base import BaseReportGenerator


class ExcelReportGenerator(BaseReportGenerator):
    """Generates .xlsx reports with rich header merging and styling."""

    def generate(
        self,
        config: ReportConfig,
        data: List[Dict[str, Any]],
        output_path: str
    ) -> str:
        wb = Workbook()
        ws = wb.active
        ws.title = "Report"

        # Title
        ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(config.table.columns))
        title_cell = ws.cell(row=1, column=1, value=config.title)
        title_cell.font = Font(name="Arial", size=14, bold=True)
        title_cell.alignment = Alignment(horizontal="center", vertical="center")

        current_row = 2
        if config.subtitle:
            ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=len(config.table.columns))
            ws.cell(row=2, column=1, value=config.subtitle)
            current_row = 3

        # === Build Header Rows with Merging ===
        header_start_row = current_row

        for hrow_idx, hrow in enumerate(config.table.header_rows):
            row_num = header_start_row + hrow_idx
            col_idx = 1

            for cell_def in hrow.cells:
                cell = ws.cell(row=row_num, column=col_idx, value=cell_def.text)

                style_name = cell_def.style
                style = config.styles.get(style_name, config.styles["sub_header"])
                self._apply_style(cell, style)

                if cell_def.colspan > 1:
                    end_col = col_idx + cell_def.colspan - 1
                    ws.merge_cells(
                        start_row=row_num,
                        start_column=col_idx,
                        end_row=row_num,
                        end_column=end_col
                    )
                    for c in range(col_idx, end_col + 1):
                        c_cell = ws.cell(row=row_num, column=c)
                        self._apply_style(c_cell, style)

                col_idx += cell_def.colspan

        # === Data Rows ===
        data_start_row = header_start_row + len(config.table.header_rows)

        for row_idx, record in enumerate(data):
            excel_row = data_start_row + row_idx
            for col_idx, col_def in enumerate(config.table.columns, start=1):
                value = record.get(col_def.key, "")
                cell = ws.cell(row=excel_row, column=col_idx, value=value)

                style = config.styles.get(col_def.style, config.styles["data_cell"])
                self._apply_style(cell, style)

                if col_def.data_type.value == "currency" and isinstance(value, (int, float)):
                    cell.number_format = '₹ #,##0.00'
                elif col_def.data_type.value == "percentage" and isinstance(value, (int, float)):
                    cell.number_format = '0.00%'

        for col_idx, col_def in enumerate(config.table.columns, start=1):
            ws.column_dimensions[get_column_letter(col_idx)].width = col_def.width_excel

        ws.freeze_panes = f"A{data_start_row}"

        wb.save(output_path)
        return output_path

    def _apply_style(self, cell, style):
        """Map StyleDef to openpyxl styles. Handles #hex → aRGB conversion."""
        def _to_argb(hex_color: str) -> str:
            if not hex_color:
                return "FF000000"
            hex_color = hex_color.lstrip("#")
            if len(hex_color) == 6:
                return "FF" + hex_color.upper()
            return hex_color.upper()

        cell.font = Font(
            name=style.font_name,
            size=style.font_size,
            bold=style.bold,
            italic=style.italic,
            color=_to_argb(style.text_color)
        )
        if style.bg_color:
            cell.fill = PatternFill(
                start_color=_to_argb(style.bg_color),
                end_color=_to_argb(style.bg_color),
                fill_type="solid"
            )

        if style.border:
            thin_border = Border(
                left=Side(style="thin", color=_to_argb(style.border_color)),
                right=Side(style="thin", color=_to_argb(style.border_color)),
                top=Side(style="thin", color=_to_argb(style.border_color)),
                bottom=Side(style="thin", color=_to_argb(style.border_color))
            )
            cell.border = thin_border

        v_align = "center" if style.vertical_alignment == "middle" else style.vertical_alignment
        cell.alignment = Alignment(
            horizontal=style.alignment.value,
            vertical=v_align,
            wrap_text=style.wrap_text
        )