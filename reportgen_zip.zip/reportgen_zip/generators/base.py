"""
Abstract base class for report generators.
"""

from abc import ABC, abstractmethod
from typing import List, Dict, Any
from ..config.models import ReportConfig


class BaseReportGenerator(ABC):
    """Abstract generator. All format-specific generators inherit from this."""

    @abstractmethod
    def generate(
        self,
        config: ReportConfig,
        data: List[Dict[str, Any]],
        output_path: str
    ) -> str:
        """
        Generate the report.
        Returns the path to the generated file.
        """
        pass