import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from reportgen.config.loader import load_report_config
from reportgen.generators.excel import ExcelReportGenerator
from reportgen.generators.pdf import PDFReportGenerator

# 1. Load config (single source of truth)
config = load_report_config("templates/sample_financial_report.yaml")

# 2. Your data (from DB, pandas, API, etc.)
data = [
    {"region": "North", "q1_revenue": 1250.75, "q1_profit": 320.50, "npa_percent": 0.023, "provision_percent": 0.018},
    {"region": "South", "q1_revenue": 980.40,  "q1_profit": 245.10, "npa_percent": 0.031, "provision_percent": 0.025},
    # ... more rows
]

# 3. Generate Excel (merged headers work perfectly)
ExcelReportGenerator().generate(config, data, "output/report.xlsx")

# 4. Generate PDF (requires: pip install weasyprint)
PDFReportGenerator().generate(config, data, "output/report.pdf")