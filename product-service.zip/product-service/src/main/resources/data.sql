-- Sample data initialization for local testing

INSERT INTO product (name) VALUES ('Laptop');
INSERT INTO product (name) VALUES ('Mouse');
INSERT INTO product (name) VALUES ('Keyboard');
INSERT INTO product (name) VALUES ('Monitor');
INSERT INTO product (name) VALUES ('USB Cable');
