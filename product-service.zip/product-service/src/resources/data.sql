INSERT INTO product (id, name) VALUES (1, 'Laptop');
INSERT INTO product (id, name) VALUES (2, 'Mouse');
INSERT INTO product (id, name) VALUES (3, 'Keyboard');
INSERT INTO product (id, name) VALUES (4, 'Monitor');
INSERT INTO product (id, name) VALUES (5, 'Headphones');